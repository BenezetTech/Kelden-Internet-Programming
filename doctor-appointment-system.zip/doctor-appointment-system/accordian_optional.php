<?php include('header.php'); ?>


	<!-- mc info -->

        
	


                                        <!-- Collapse from Bootstrap -->
                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                      Qualifications
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                  <div class="panel-body">
                                                        MBBS, FCPS(Medicine) <br>
                                                        MD(Internal Medicine)<br>
                                                        FACP(America) <br>
                                                        Designation : Associate Professor <br>
                                                        Expertise : Medicine <br>
                                                        Organization: Sir Salimullah Medical College and Mitford Hospital
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingTwo">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                      Chamber
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                                  <div class="panel-body">
                                                        Health &amp; Hope Hospital Ltd.
                                                        Visiting Hours:
                                                        Location: 152/1-H, Green Road, Panthapath,
                                                        Dhaka - 1205, Bangladesh
                                                       
                                                  </div>
                                                </div>
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                      Contact
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                  <div class="panel-body">
                                                     Phone: +880-2-9145786, 9137076, 01819494530
                                                  </div>
                                                </div>
                                              </div>
                                             <!--  extra made by me -->

                                             <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="registration.php">
                                                      Get Appoinment
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>

                                            </div> <!-- accordian End -->
                                        
                               

    <!-- footer section --> 
			 <?php include('footer.php'); ?>
    <!-- footer section Ends--> 
	



		
	</div><!--  containerFluid Ends -->


                <script src="js/jquery-1.11.3.min.js"></script>
                <script src="js/bootstrap.min.js"></script>
	
</body>
</html>






